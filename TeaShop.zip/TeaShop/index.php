<?php
/**
 * Author: Jon Ross Richardson
 * Date: 6/15/2022
 * File: ${FILENAME}
 * Description:
 */

$page_title = "SpillTheTeaOnline";
include'includes/header.php';
?>
<h2>Welcome to Spill the Tea Online Store</h2>

